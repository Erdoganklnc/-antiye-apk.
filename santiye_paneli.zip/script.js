
function login() {
  const password = document.getElementById("password").value;
  if (password === "1234santiye") {
    document.getElementById("login").style.display = "none";
    document.getElementById("panel").style.display = "block";
  } else {
    document.getElementById("error").textContent = "Hatalı şifre!";
  }
}
